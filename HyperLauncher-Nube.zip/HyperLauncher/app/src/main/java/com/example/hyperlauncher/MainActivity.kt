package com.example.hyperlauncher

import android.app.*
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("layout", MODE_PRIVATE) }
    private val host by lazy { AppWidgetHost(this, 3021) }
    private val manager by lazy { AppWidgetManager.getInstance(this) }
    private val widgetIds = mutableListOf<Int>()
    private val apps by lazy {
        packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }
    private fun dp(v:Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color:Int, radius:Int=22): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat() }
    private fun label(text:String, size:Float=15f, color:Int=Color.WHITE) = TextView(this).apply { this.text=text; textSize=size; setTextColor(color); gravity=Gravity.CENTER }
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=Color.rgb(25,40,80); window.navigationBarColor=Color.rgb(20,30,60); showHome() }
    override fun onStart() { super.onStart(); host.startListening() }
    override fun onStop() { host.stopListening(); super.onStop() }
    private fun base(title:String) {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(22),dp(14),dp(12)); background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(25,50,106),Color.rgb(77,98,167),Color.rgb(20,30,64))) }
        setContentView(root)
        val header=label(title,25f).apply { typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.START }
        root.addView(header,LinearLayout.LayoutParams(-1,dp(55)))
    }
    private fun button(text:String, action:()->Unit): TextView = label(text,14f).apply { background=bg(0x55FFFFFF,16); setPadding(dp(10),dp(10),dp(10),dp(10)); setOnClickListener { action() } }
    private fun appTile(index:Int):LinearLayout {
        val info=apps[index]
        val tile=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(dp(2),dp(6),dp(2),dp(6)) }
        tile.addView(ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)) },LinearLayout.LayoutParams(dp(48),dp(48)))
        tile.addView(label(info.loadLabel(packageManager).toString(),11f).apply { maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END },LinearLayout.LayoutParams(-1,dp(26)))
        tile.setOnClickListener { try { startActivity(packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)) } catch (_:Exception) { Toast.makeText(this,"No se pudo abrir",Toast.LENGTH_SHORT).show() } }
        tile.setOnLongClickListener { showFolderDialog(index); true }
        return tile
    }
    private fun grid(indices:List<Int>):GridLayout = GridLayout(this).apply {
        columnCount=4
        indices.forEach { index -> addView(appTile(index),GridLayout.LayoutParams().apply { width=(resources.displayMetrics.widthPixels-dp(28))/4; height=dp(96) }) }
    }
    private fun showHome() {
        base("Hyper Launcher")
        val bar=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf("Apps" to { showDrawer() },"+ Carpeta" to { createFolder() },"+ Widget" to { pickWidget() },"Ajustes" to { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }).forEach { (name,fn) -> bar.addView(button(name,fn),LinearLayout.LayoutParams(0,dp(48),1f).apply { setMargins(dp(2),0,dp(2),0) }) }
        root.addView(bar)
        val scroll=ScrollView(this)
        val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        content.addView(label("Mis aplicaciones",18f).apply { gravity=Gravity.START; setPadding(0,dp(18),0,dp(10)) })
        content.addView(grid(apps.indices.take(16).toList()))
        val folderNames=prefs.getString("folders","")!!.split("|").filter { it.isNotBlank() }
        folderNames.forEach { name ->
            content.addView(button("📁 $name") { openFolder(name) },LinearLayout.LayoutParams(-1,dp(55)).apply { bottomMargin=dp(8) })
        }
        widgetIds.clear()
        prefs.getString("widgets","")!!.split(",").mapNotNull { it.toIntOrNull() }.forEach { id ->
            try { val info=manager.getAppWidgetInfo(id); if(info!=null) { widgetIds.add(id); val view=host.createView(this,id,info); content.addView(view,LinearLayout.LayoutParams(-1,dp(190)).apply { bottomMargin=dp(10) }); view.setOnLongClickListener { removeWidget(id); true } } } catch (_:Exception) {}
        }
        scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(button("Buscar todas las aplicaciones") { showDrawer() },LinearLayout.LayoutParams(-1,dp(55)))
    }
    private fun showDrawer() {
        base("Aplicaciones")
        root.addView(button("‹ Inicio") { showHome() })
        val search=EditText(this).apply { hint="Buscar aplicaciones"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        root.addView(search)
        val scroll=ScrollView(this); val holder=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; scroll.addView(holder); root.addView(scroll)
        fun refresh(q:String) { holder.removeAllViews(); holder.addView(grid(apps.indices.filter { apps[it].loadLabel(packageManager).toString().contains(q,true) })) }
        search.addTextChangedListener(object:android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}; override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refresh(s.toString())}; override fun afterTextChanged(s:android.text.Editable?){} })
        refresh("")
    }
    private fun createFolder() {
        val input=EditText(this).apply { hint="Nombre de la carpeta" }
        AlertDialog.Builder(this).setTitle("Nueva carpeta").setView(input).setPositiveButton("Crear") { _,_ ->
            val name=input.text.toString().trim().replace("|",""); if(name.isNotEmpty()) { val current=prefs.getString("folders","")!!; prefs.edit().putString("folders",(current.split("|").filter { it.isNotBlank() }+name).distinct().joinToString("|")).apply(); showHome() }
        }.setNegativeButton("Cancelar",null).show()
    }
    private fun showFolderDialog(index:Int) {
        val folders=prefs.getString("folders","")!!.split("|").filter { it.isNotBlank() }
        if(folders.isEmpty()) { createFolder(); return }
        AlertDialog.Builder(this).setTitle("Añadir a carpeta").setItems(folders.toTypedArray()) { _,which ->
            val name=folders[which]; val key="folder_$name"; val ids=prefs.getString(key,"")!!.split(",").mapNotNull { it.toIntOrNull() }; prefs.edit().putString(key,(ids+index).distinct().joinToString(",")).apply(); Toast.makeText(this,"Añadida a $name",Toast.LENGTH_SHORT).show()
        }.show()
    }
    private fun openFolder(name:String) {
        base("📁 $name")
        root.addView(button("‹ Inicio") { showHome() })
        val indices=prefs.getString("folder_$name","")!!.split(",").mapNotNull { it.toIntOrNull() }.filter { it in apps.indices }
        root.addView(grid(indices))
        root.addView(button("Añadir aplicaciones") { showDrawer() })
        root.addView(button("Eliminar carpeta") { val names=prefs.getString("folders","")!!.split("|").filter { it!=name }; prefs.edit().putString("folders",names.joinToString("|")).remove("folder_$name").apply(); showHome() })
    }
    private fun pickWidget() {
        val id=host.allocateAppWidgetId()
        try { startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id),101) }
        catch (_:Exception) { host.deleteAppWidgetId(id); Toast.makeText(this,"Selector de widgets no disponible",Toast.LENGTH_LONG).show() }
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==101) {
            val id=data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1) ?: -1
            if(resultCode==RESULT_OK && id!=-1) { val info=manager.getAppWidgetInfo(id); if(info!=null && !manager.bindAppWidgetIdIfAllowed(id,info.provider)) {
                try { startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id).putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER,info.provider),102); return } catch (_:Exception) {} }
                saveWidget(id)
            } else if(id!=-1) host.deleteAppWidgetId(id)
        } else if(requestCode==102) { val id=data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1) ?: -1; if(id!=-1) { if(resultCode==RESULT_OK) saveWidget(id) else host.deleteAppWidgetId(id) } }
    }
    private fun saveWidget(id:Int) { prefs.edit().putString("widgets",(widgetIds+id).distinct().joinToString(",")).apply(); showHome() }
    private fun removeWidget(id:Int):Boolean { AlertDialog.Builder(this).setMessage("¿Eliminar este widget?").setPositiveButton("Eliminar") { _,_ -> host.deleteAppWidgetId(id); prefs.edit().putString("widgets",widgetIds.filter { it!=id }.joinToString(",")).apply(); showHome() }.setNegativeButton("Cancelar",null).show(); return true }
    override fun onBackPressed() { showHome() }
}
