# Hyper Launcher
Launcher independiente inspirado en HyperOS (no oficial de Xiaomi).

## Compilar
1. Abre esta carpeta con Android Studio (JDK 17).
2. Espera la sincronización de Gradle y la descarga de Android SDK 35.
3. Selecciona Build > Build APK(s).
4. Encontrarás el APK en `app/build/outputs/apk/debug/app-debug.apk`.
5. Instálalo y selecciona Hyper Launcher como app de inicio en los ajustes de Android.

## Funciones
Pantalla de inicio, lista y búsqueda de apps, carpetas persistentes, widgets Android, selector de launcher predeterminado.

## Limitaciones
Prototipo funcional inicial: las carpetas guardan índices de apps y pueden cambiar tras instalar/desinstalar paquetes; los widgets dependen de compatibilidad del fabricante; no incluye animaciones ni centro de control del sistema. No está probado en dispositivo físico. El APK requiere compilarse en Android Studio.

## Compilar en la nube desde una tablet (GitHub Actions)
1. Crea un repositorio nuevo en github.com (puede ser privado).
2. Sube el **contenido** de la carpeta HyperLauncher a la raíz del repositorio, incluida `.github/workflows/build-apk.yml`.
3. En el repositorio, abre Actions > Compilar APK Android > Run workflow (o espera la ejecución automática tras subir los archivos).
4. Cuando termine correctamente, entra en la ejecución y descarga el artifact `HyperLauncher-APK`.
5. Descomprime el artifact y abre `app-debug.apk` en tu tablet Android para instalarlo.

Si la compilación falla, revisa el registro en Actions. Esta configuración aún no se ha verificado con una ejecución real.
